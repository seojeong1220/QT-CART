/********************************************************************************
** Form generated from reading UI file 'pagepay.ui'
**
** Created by: Qt User Interface Compiler version 5.15.15
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PAGEPAY_H
#define UI_PAGEPAY_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_PagePay
{
public:
    QHBoxLayout *horizontalLayout;
    QFrame *frame;
    QPushButton *btnNext;
    QPushButton *btnBack;
    QFrame *frame_2;
    QLabel *lblCardIcon;
    QLabel *lblCarGuide;
    QLabel *label_4;
    QLabel *label_2;
    QLabel *label_5;
    QWidget *widget;
    QLabel *label_3;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_12;
    QTableWidget *tablePayItems;
    QFrame *frame_3;
    QLabel *label_10;
    QLabel *lblTotalPriceValue;
    QLabel *label_8;

    void setupUi(QWidget *PagePay)
    {
        if (PagePay->objectName().isEmpty())
            PagePay->setObjectName(QString::fromUtf8("PagePay"));
        PagePay->resize(800, 480);
        PagePay->setStyleSheet(QString::fromUtf8("background-color: #F2F4F7;"));
        horizontalLayout = new QHBoxLayout(PagePay);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        frame = new QFrame(PagePay);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setFrameShape(QFrame::Shape::StyledPanel);
        frame->setFrameShadow(QFrame::Shadow::Raised);
        btnNext = new QPushButton(frame);
        btnNext->setObjectName(QString::fromUtf8("btnNext"));
        btnNext->setGeometry(QRect(460, 370, 281, 61));
        btnNext->setStyleSheet(QString::fromUtf8("background-color: rgb(53, 132, 228);\n"
"color: rgb(255, 255, 255);\n"
"border: none;\n"
"border-radius: 14px;\n"
"padding: 10px 18px;\n"
"font: 14pt \"Ubuntu\";"));
        btnBack = new QPushButton(frame);
        btnBack->setObjectName(QString::fromUtf8("btnBack"));
        btnBack->setGeometry(QRect(610, 10, 95, 41));
        btnBack->setStyleSheet(QString::fromUtf8("background-color: rgb(154, 153, 150);\n"
"color: rgb(255, 255, 255);\n"
"border: none;\n"
"border-radius: 14px;\n"
"padding: 10px 18px;"));
        frame_2 = new QFrame(frame);
        frame_2->setObjectName(QString::fromUtf8("frame_2"));
        frame_2->setGeometry(QRect(460, 90, 281, 271));
        frame_2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border-radius: 16px;"));
        frame_2->setFrameShape(QFrame::Shape::StyledPanel);
        frame_2->setFrameShadow(QFrame::Shadow::Raised);
        lblCardIcon = new QLabel(frame_2);
        lblCardIcon->setObjectName(QString::fromUtf8("lblCardIcon"));
        lblCardIcon->setGeometry(QRect(30, -10, 201, 211));
        lblCardIcon->setStyleSheet(QString::fromUtf8("image: url(:/etc/card.png);"));
        lblCarGuide = new QLabel(frame_2);
        lblCarGuide->setObjectName(QString::fromUtf8("lblCarGuide"));
        lblCarGuide->setGeometry(QRect(50, 200, 241, 41));
        lblCarGuide->setStyleSheet(QString::fromUtf8("font: 500 12pt \"Ubuntu\";"));
        label_4 = new QLabel(frame);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(330, 19, 121, 20));
        label_4->setStyleSheet(QString::fromUtf8("font: 13pt \"Ubuntu Condensed\";\n"
"color: rgb(0, 0, 0);\n"
"background-color: #F2F4F7;\n"
""));
        label_2 = new QLabel(frame);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(220, 20, 111, 17));
        label_2->setStyleSheet(QString::fromUtf8("font: 13pt \"Ubuntu Condensed\";\n"
"color: rgb(154, 153, 150);\n"
"background-color: #F2F4F7;"));
        label_5 = new QLabel(frame);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(20, 50, 301, 31));
        label_5->setStyleSheet(QString::fromUtf8("font: 13pt \"Ubuntu Condensed\";\n"
"color: rgb(0, 0, 0)"));
        widget = new QWidget(frame);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(10, 90, 441, 341));
        widget->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border-radius: 16px;"));
        label_3 = new QLabel(widget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(10, 10, 141, 41));
        label_3->setStyleSheet(QString::fromUtf8("font: 500 20pt \"Ubuntu\";"));
        label_6 = new QLabel(widget);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(10, 50, 91, 41));
        label_6->setStyleSheet(QString::fromUtf8("font: 15pt \"Ubuntu Mono\";"));
        label_7 = new QLabel(widget);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(230, 50, 91, 41));
        label_7->setStyleSheet(QString::fromUtf8("font: 15pt \"Ubuntu Mono\";"));
        label_12 = new QLabel(widget);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(385, 50, 91, 41));
        label_12->setStyleSheet(QString::fromUtf8("font: 15pt \"Ubuntu Mono\";"));
        tablePayItems = new QTableWidget(widget);
        tablePayItems->setObjectName(QString::fromUtf8("tablePayItems"));
        tablePayItems->setGeometry(QRect(0, 90, 441, 191));
        tablePayItems->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border-radius: 0px;\n"
"font: 300 13pt \"Umpush\";\n"
"border-top: 1px solid #cfcfcf;\n"
"border-bottom: 0px;\n"
"border-left: 0px;\n"
"border-right: 0px;"));
        frame_3 = new QFrame(widget);
        frame_3->setObjectName(QString::fromUtf8("frame_3"));
        frame_3->setGeometry(QRect(0, 290, 451, 51));
        frame_3->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border-style: solid;\n"
"border-top: 1px solid rgb(200, 200, 200);\n"
"border-left: 1px solid rgb(255, 255, 255);\n"
"border-right: 1px solid rgb(255, 255, 255);\n"
"border-bottom: 1px solid rgb(255, 255, 255);\n"
"border-radius: 0px;"));
        frame_3->setFrameShape(QFrame::Shape::StyledPanel);
        frame_3->setFrameShadow(QFrame::Shadow::Raised);
        label_10 = new QLabel(frame_3);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(20, 10, 121, 31));
        label_10->setStyleSheet(QString::fromUtf8("font: 700 16pt \"Umpush\";\n"
"background-color: rgb(255, 255, 255);\n"
"border: none;\n"
""));
        lblTotalPriceValue = new QLabel(frame_3);
        lblTotalPriceValue->setObjectName(QString::fromUtf8("lblTotalPriceValue"));
        lblTotalPriceValue->setGeometry(QRect(240, 10, 101, 41));
        lblTotalPriceValue->setStyleSheet(QString::fromUtf8("border: none;\n"
"font: 15pt \"Umpush\";\n"
"color: rgb(28, 113, 216);"));
        label_8 = new QLabel(frame);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(460, 20, 111, 17));
        label_8->setStyleSheet(QString::fromUtf8("font: 13pt \"Ubuntu Condensed\";\n"
"color: rgb(154, 153, 150);\n"
"background-color: #F2F4F7;"));

        horizontalLayout->addWidget(frame);


        retranslateUi(PagePay);

        QMetaObject::connectSlotsByName(PagePay);
    } // setupUi

    void retranslateUi(QWidget *PagePay)
    {
        PagePay->setWindowTitle(QCoreApplication::translate("PagePay", "Form", nullptr));
        btnNext->setText(QCoreApplication::translate("PagePay", "\353\213\244\354\235\214\354\234\274\353\241\234 \353\204\230\354\226\264\352\260\200\352\270\260", nullptr));
        btnBack->setText(QCoreApplication::translate("PagePay", "\354\235\264\354\240\204 \355\231\224\353\251\264", nullptr));
        lblCardIcon->setText(QString());
        lblCarGuide->setText(QCoreApplication::translate("PagePay", "\354\271\264\353\223\234\353\245\274  \355\210\254\354\236\205\352\265\254\354\227\220 \353\204\243\354\226\264\354\243\274\354\204\270\354\232\224", nullptr));
        label_4->setText(QCoreApplication::translate("PagePay", "O Checkout   ", nullptr));
        label_2->setText(QCoreApplication::translate("PagePay", "O Cart    ", nullptr));
        label_5->setText(QCoreApplication::translate("PagePay", "\354\225\204\353\236\230 \352\265\254\353\247\244 \353\202\264\354\227\255\354\235\204 \355\231\225\354\235\270\355\225\264\354\243\274\354\204\270\354\232\224", nullptr));
        label_3->setText(QCoreApplication::translate("PagePay", "\352\265\254\353\247\244 \353\202\264\354\227\255", nullptr));
        label_6->setText(QCoreApplication::translate("PagePay", "Prdoucts", nullptr));
        label_7->setText(QCoreApplication::translate("PagePay", "Count", nullptr));
        label_12->setText(QCoreApplication::translate("PagePay", "Price", nullptr));
        label_10->setText(QCoreApplication::translate("PagePay", "\354\264\235 \352\262\260\354\240\234\352\270\210\354\225\241", nullptr));
        lblTotalPriceValue->setText(QString());
        label_8->setText(QCoreApplication::translate("PagePay", "O Payment   ", nullptr));
    } // retranslateUi

};

namespace Ui {
    class PagePay: public Ui_PagePay {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PAGEPAY_H
