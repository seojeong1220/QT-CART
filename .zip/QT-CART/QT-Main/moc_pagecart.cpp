/****************************************************************************
** Meta object code from reading C++ file 'pagecart.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.15)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "pagecart.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'pagecart.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.15. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_PageCart_t {
    QByteArrayData data[19];
    char stringdata0[252];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_PageCart_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_PageCart_t qt_meta_stringdata_PageCart = {
    {
QT_MOC_LITERAL(0, 0, 8), // "PageCart"
QT_MOC_LITERAL(1, 9, 16), // "guideModeClicked"
QT_MOC_LITERAL(2, 26, 0), // ""
QT_MOC_LITERAL(3, 27, 9), // "goWelcome"
QT_MOC_LITERAL(4, 37, 15), // "requestCheckout"
QT_MOC_LITERAL(5, 53, 11), // "totalWeight"
QT_MOC_LITERAL(6, 65, 9), // "resetCart"
QT_MOC_LITERAL(7, 75, 13), // "onPlusClicked"
QT_MOC_LITERAL(8, 89, 14), // "onMinusClicked"
QT_MOC_LITERAL(9, 104, 15), // "onDeleteClicked"
QT_MOC_LITERAL(10, 120, 16), // "onBarcodeEntered"
QT_MOC_LITERAL(11, 137, 17), // "handleItemFetched"
QT_MOC_LITERAL(12, 155, 4), // "Item"
QT_MOC_LITERAL(13, 160, 4), // "item"
QT_MOC_LITERAL(14, 165, 17), // "handleFetchFailed"
QT_MOC_LITERAL(15, 183, 3), // "err"
QT_MOC_LITERAL(16, 187, 21), // "on_pushButton_clicked"
QT_MOC_LITERAL(17, 209, 22), // "on_btnCheckout_clicked"
QT_MOC_LITERAL(18, 232, 19) // "on_btnGuide_clicked"

    },
    "PageCart\0guideModeClicked\0\0goWelcome\0"
    "requestCheckout\0totalWeight\0resetCart\0"
    "onPlusClicked\0onMinusClicked\0"
    "onDeleteClicked\0onBarcodeEntered\0"
    "handleItemFetched\0Item\0item\0"
    "handleFetchFailed\0err\0on_pushButton_clicked\0"
    "on_btnCheckout_clicked\0on_btnGuide_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_PageCart[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      13,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   79,    2, 0x06 /* Public */,
       3,    0,   80,    2, 0x06 /* Public */,
       4,    1,   81,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       6,    0,   84,    2, 0x0a /* Public */,
       7,    0,   85,    2, 0x08 /* Private */,
       8,    0,   86,    2, 0x08 /* Private */,
       9,    0,   87,    2, 0x08 /* Private */,
      10,    0,   88,    2, 0x08 /* Private */,
      11,    1,   89,    2, 0x08 /* Private */,
      14,    1,   92,    2, 0x08 /* Private */,
      16,    0,   95,    2, 0x08 /* Private */,
      17,    0,   96,    2, 0x08 /* Private */,
      18,    0,   97,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Double,    5,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 12,   13,
    QMetaType::Void, QMetaType::QString,   15,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void PageCart::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<PageCart *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->guideModeClicked(); break;
        case 1: _t->goWelcome(); break;
        case 2: _t->requestCheckout((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 3: _t->resetCart(); break;
        case 4: _t->onPlusClicked(); break;
        case 5: _t->onMinusClicked(); break;
        case 6: _t->onDeleteClicked(); break;
        case 7: _t->onBarcodeEntered(); break;
        case 8: _t->handleItemFetched((*reinterpret_cast< const Item(*)>(_a[1]))); break;
        case 9: _t->handleFetchFailed((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 10: _t->on_pushButton_clicked(); break;
        case 11: _t->on_btnCheckout_clicked(); break;
        case 12: _t->on_btnGuide_clicked(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (PageCart::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&PageCart::guideModeClicked)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (PageCart::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&PageCart::goWelcome)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (PageCart::*)(double );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&PageCart::requestCheckout)) {
                *result = 2;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject PageCart::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_PageCart.data,
    qt_meta_data_PageCart,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *PageCart::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *PageCart::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_PageCart.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int PageCart::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 13)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 13;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 13)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 13;
    }
    return _id;
}

// SIGNAL 0
void PageCart::guideModeClicked()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void PageCart::goWelcome()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void PageCart::requestCheckout(double _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
