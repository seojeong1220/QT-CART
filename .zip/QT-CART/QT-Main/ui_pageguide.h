/********************************************************************************
** Form generated from reading UI file 'pageguide.ui'
**
** Created by: Qt User Interface Compiler version 5.15.15
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PAGEGUIDE_H
#define UI_PAGEGUIDE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_PageGuide
{
public:
    QGridLayout *gridLayout;
    QFrame *frame;
    QPushButton *btnpay;
    QPushButton *btnpuzzle;
    QPushButton *btnsnack;
    QPushButton *btnBackToCart;
    QLabel *label;
    QLabel *lblmap;
    QLabel *label_3;
    QPushButton *btnphone;
    QPushButton *btncream;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QFrame *frameCornerList;
    QLabel *lblCornerTitle;
    QListWidget *listCorners;
    QLabel *label_8;

    void setupUi(QWidget *PageGuide)
    {
        if (PageGuide->objectName().isEmpty())
            PageGuide->setObjectName(QString::fromUtf8("PageGuide"));
        PageGuide->resize(800, 480);
        gridLayout = new QGridLayout(PageGuide);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        frame = new QFrame(PageGuide);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setStyleSheet(QString::fromUtf8("/* ===== \354\271\264\353\223\234(\355\224\204\353\240\210\354\236\204) ===== */\n"
"QFrame#frameCornerList {\n"
"    background-color: rgb(255, 255, 255);\n"
"    border-radius: 16px;\n"
"    border: 1px solid rgb(229, 231, 235);   /* \354\227\260\355\232\214\354\203\211 */\n"
"}\n"
"\n"
"/* \354\240\234\353\252\251 \353\235\274\353\262\250 */\n"
"QLabel#lblCornerTitle {\n"
"    background: transparent;\n"
"    color: rgb(17, 24, 39);                 /* \354\247\204\355\225\234 \352\270\200\354\224\250 */\n"
"    font-size: 20px;\n"
"    font-weight: 800;\n"
"}\n"
"\n"
"/* ===== \353\246\254\354\212\244\355\212\270 \354\234\204\354\240\257 ===== */\n"
"QListWidget#listCorners {\n"
"    background: transparent;\n"
"    border: none;\n"
"    outline: 0;\n"
"    padding: 6px;\n"
"}\n"
"\n"
"/* \354\212\244\355\201\254\353\241\244\353\260\224 \352\271\224\353\201\224\355\225\230\352\262\214 (\354\204\240\355\203\235) */\n"
"QListWidget#listCorners QScrollBar:vertical {\n"
"    width: 10px;\n"
"    background: tra"
                        "nsparent;\n"
"}\n"
"QListWidget#listCorners QScrollBar::handle:vertical {\n"
"    background: rgb(209, 213, 219);\n"
"    border-radius: 5px;\n"
"    min-height: 20px;\n"
"}\n"
"QListWidget#listCorners QScrollBar::add-line:vertical,\n"
"QListWidget#listCorners QScrollBar::sub-line:vertical {\n"
"    height: 0px;\n"
"}\n"
"\n"
"/* ===== \354\225\204\354\235\264\355\205\234(\355\226\211) \354\212\244\355\203\200\354\235\274 ===== */\n"
"QListWidget#listCorners::item {\n"
"    background-color: rgb(249, 250, 251);   /* \354\202\264\354\247\235 \355\232\214\354\203\211 */\n"
"    border: 1px solid rgb(229, 231, 235);\n"
"    border-radius: 12px;\n"
"\n"
"    padding: 14px 16px;   /* \354\225\210\354\252\275 \354\227\254\353\260\261 */\n"
"    margin: 6px 4px;      /* \354\225\204\354\235\264\355\205\234 \352\260\204 \352\260\204\352\262\251 */\n"
"\n"
"    color: rgb(17, 24, 39);\n"
"    font-size: 16px;\n"
"    font-weight: 700;\n"
"}\n"
"\n"
"\n"
""));
        frame->setFrameShape(QFrame::Shape::StyledPanel);
        frame->setFrameShadow(QFrame::Shadow::Raised);
        btnpay = new QPushButton(frame);
        btnpay->setObjectName(QString::fromUtf8("btnpay"));
        btnpay->setGeometry(QRect(90, 350, 61, 51));
        btnpay->setStyleSheet(QString::fromUtf8("border-image: url(:/etc/map_pay.png);"));
        btnpuzzle = new QPushButton(frame);
        btnpuzzle->setObjectName(QString::fromUtf8("btnpuzzle"));
        btnpuzzle->setGeometry(QRect(390, 150, 61, 61));
        btnpuzzle->setStyleSheet(QString::fromUtf8("border-image: url(:/etc/map_toy_2.png);\n"
"\n"
"QPushButton#Region1:hover{\n"
"	background-color: rgb(222, 221, 218);\n"
"};\n"
"QPushButton#Region1:pressed{\n"
"	background-color: rgb(222, 221, 218);\n"
"}"));
        btnsnack = new QPushButton(frame);
        btnsnack->setObjectName(QString::fromUtf8("btnsnack"));
        btnsnack->setGeometry(QRect(190, 170, 61, 71));
        btnsnack->setStyleSheet(QString::fromUtf8("border-image: url(:/etc/map_snack.png);"));
        btnBackToCart = new QPushButton(frame);
        btnBackToCart->setObjectName(QString::fromUtf8("btnBackToCart"));
        btnBackToCart->setGeometry(QRect(550, 10, 201, 41));
        btnBackToCart->setStyleSheet(QString::fromUtf8("background-color: rgb(53, 132, 228);\n"
"color: rgb(255, 255, 255);\n"
"border: none;\n"
"border-radius: 14px;\n"
"padding: 10px 18px;\n"
"font: 14pt \"Ubuntu\";"));
        label = new QLabel(frame);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(10, 10, 121, 31));
        label->setStyleSheet(QString::fromUtf8("font: 700 22pt \"Ubuntu\";\n"
"color: rgb(46, 194, 126);"));
        lblmap = new QLabel(frame);
        lblmap->setObjectName(QString::fromUtf8("lblmap"));
        lblmap->setGeometry(QRect(20, 70, 521, 341));
        lblmap->setBaseSize(QSize(780, 800));
        lblmap->setStyleSheet(QString::fromUtf8("border-image: url(:/etc/guide_map.png);\n"
"\n"
"border-style: solid;\n"
"border-top: 3px solid rgb(200, 200, 200);\n"
"border-left: 3px solid rgb(200, 200, 200);\n"
"border-right: 3px solid rgb(200, 200, 200);\n"
"border-bottom: 3px solid rgb(200, 200, 200);\n"
"\n"
"\n"
"\n"
"\n"
""));
        label_3 = new QLabel(frame);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(140, 20, 391, 20));
        label_3->setStyleSheet(QString::fromUtf8("font: 300 italic 11pt \"Ubuntu\";\n"
"color: rgb(224, 27, 36);"));
        btnphone = new QPushButton(frame);
        btnphone->setObjectName(QString::fromUtf8("btnphone"));
        btnphone->setGeometry(QRect(100, 290, 51, 51));
        btnphone->setStyleSheet(QString::fromUtf8("border-image: url(:/etc/map_phone_1.png);"));
        btncream = new QPushButton(frame);
        btncream->setObjectName(QString::fromUtf8("btncream"));
        btncream->setGeometry(QRect(390, 350, 51, 51));
        btncream->setStyleSheet(QString::fromUtf8("border-image: url(:/etc/map_cream.png);"));
        label_4 = new QLabel(frame);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(180, 180, 21, 17));
        label_4->setStyleSheet(QString::fromUtf8("font: 700 14pt \"Ubuntu\";\n"
"color: rgb(255, 255, 255);\n"
"background-color: rgb(224, 27, 36);"));
        label_5 = new QLabel(frame);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(380, 140, 21, 17));
        label_5->setStyleSheet(QString::fromUtf8("font: 700 14pt \"Ubuntu\";\n"
"color: rgb(255, 255, 255);\n"
"background-color: rgb(224, 27, 36);"));
        label_6 = new QLabel(frame);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(370, 350, 21, 20));
        label_6->setStyleSheet(QString::fromUtf8("font: 700 14pt \"Ubuntu\";\n"
"color: rgb(255, 255, 255);\n"
"background-color: rgb(224, 27, 36);"));
        label_7 = new QLabel(frame);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(80, 290, 21, 17));
        label_7->setStyleSheet(QString::fromUtf8("font: 700 14pt \"Ubuntu\";\n"
"color: rgb(255, 255, 255);\n"
"background-color: rgb(224, 27, 36);"));
        frameCornerList = new QFrame(frame);
        frameCornerList->setObjectName(QString::fromUtf8("frameCornerList"));
        frameCornerList->setGeometry(QRect(560, 60, 191, 361));
        frameCornerList->setFrameShape(QFrame::Shape::StyledPanel);
        frameCornerList->setFrameShadow(QFrame::Shadow::Raised);
        lblCornerTitle = new QLabel(frameCornerList);
        lblCornerTitle->setObjectName(QString::fromUtf8("lblCornerTitle"));
        lblCornerTitle->setGeometry(QRect(60, 0, 81, 31));
        lblCornerTitle->setStyleSheet(QString::fromUtf8("\n"
"font: 700 16pt \"Ubuntu\";"));
        listCorners = new QListWidget(frameCornerList);
        new QListWidgetItem(listCorners);
        new QListWidgetItem(listCorners);
        new QListWidgetItem(listCorners);
        new QListWidgetItem(listCorners);
        new QListWidgetItem(listCorners);
        listCorners->setObjectName(QString::fromUtf8("listCorners"));
        listCorners->setGeometry(QRect(0, 30, 191, 341));
        listCorners->setStyleSheet(QString::fromUtf8("font: 11pt \"Ubuntu\";"));
        label_8 = new QLabel(frame);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(70, 360, 21, 17));
        label_8->setStyleSheet(QString::fromUtf8("font: 700 14pt \"Ubuntu\";\n"
"color: rgb(255, 255, 255);\n"
"background-color: rgb(224, 27, 36);"));
        lblmap->raise();
        btnpay->raise();
        btnpuzzle->raise();
        btnsnack->raise();
        btnBackToCart->raise();
        label->raise();
        label_3->raise();
        btnphone->raise();
        btncream->raise();
        label_4->raise();
        label_5->raise();
        label_6->raise();
        label_7->raise();
        frameCornerList->raise();
        label_8->raise();

        gridLayout->addWidget(frame, 0, 1, 1, 1);


        retranslateUi(PageGuide);

        QMetaObject::connectSlotsByName(PageGuide);
    } // setupUi

    void retranslateUi(QWidget *PageGuide)
    {
        PageGuide->setWindowTitle(QCoreApplication::translate("PageGuide", "Form", nullptr));
        btnpay->setText(QString());
        btnpuzzle->setText(QString());
        btnsnack->setText(QString());
        btnBackToCart->setText(QCoreApplication::translate("PageGuide", "\354\236\245\353\260\224\352\265\254\353\213\210\353\241\234 \353\217\214\354\225\204\352\260\200\352\270\260", nullptr));
        label->setText(QCoreApplication::translate("PageGuide", "\354\225\210\353\202\264 \354\247\200\353\217\204", nullptr));
        lblmap->setText(QString());
        label_3->setText(QCoreApplication::translate("PageGuide", "**\354\247\200\353\217\204\354\235\230 \354\225\204\354\235\264\354\275\230\354\235\204 \355\204\260\354\271\230\355\225\230\353\251\264 \355\225\264\353\213\271 \352\265\254\354\227\255\354\234\274\353\241\234 \354\225\210\353\202\264\352\260\200 \354\213\234\354\236\221\353\220\251\353\213\210\353\213\244", nullptr));
        btnphone->setText(QString());
        btncream->setText(QString());
        label_4->setText(QCoreApplication::translate("PageGuide", "01", nullptr));
        label_5->setText(QCoreApplication::translate("PageGuide", "02", nullptr));
        label_6->setText(QCoreApplication::translate("PageGuide", "03", nullptr));
        label_7->setText(QCoreApplication::translate("PageGuide", "04", nullptr));
        lblCornerTitle->setText(QCoreApplication::translate("PageGuide", "\353\254\274\355\222\210\354\234\204\354\271\230", nullptr));

        const bool __sortingEnabled = listCorners->isSortingEnabled();
        listCorners->setSortingEnabled(false);
        QListWidgetItem *___qlistwidgetitem = listCorners->item(0);
        ___qlistwidgetitem->setText(QCoreApplication::translate("PageGuide", "01\354\275\224\353\204\210 \354\213\235\355\222\210", nullptr));
        QListWidgetItem *___qlistwidgetitem1 = listCorners->item(1);
        ___qlistwidgetitem1->setText(QCoreApplication::translate("PageGuide", "02\354\275\224\353\204\210 \354\236\245\353\202\234\352\260\220", nullptr));
        QListWidgetItem *___qlistwidgetitem2 = listCorners->item(2);
        ___qlistwidgetitem2->setText(QCoreApplication::translate("PageGuide", "03\354\275\224\353\204\210 \354\203\235\355\225\204\355\222\210", nullptr));
        QListWidgetItem *___qlistwidgetitem3 = listCorners->item(3);
        ___qlistwidgetitem3->setText(QCoreApplication::translate("PageGuide", "04\354\275\224\353\204\210 \354\240\204\354\236\220\354\240\234\355\222\210", nullptr));
        QListWidgetItem *___qlistwidgetitem4 = listCorners->item(4);
        ___qlistwidgetitem4->setText(QCoreApplication::translate("PageGuide", "05\354\275\224\353\204\210 \352\263\204\354\202\260\353\214\200", nullptr));
        listCorners->setSortingEnabled(__sortingEnabled);

        label_8->setText(QCoreApplication::translate("PageGuide", "05", nullptr));
    } // retranslateUi

};

namespace Ui {
    class PageGuide: public Ui_PageGuide {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PAGEGUIDE_H
