/********************************************************************************
** Form generated from reading UI file 'pagecart.ui'
**
** Created by: Qt User Interface Compiler version 5.15.15
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PAGECART_H
#define UI_PAGECART_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_PageCart
{
public:
    QHBoxLayout *horizontalLayout;
    QFrame *frame_2;
    QWidget *widget_2;
    QTableWidget *tableCart;
    QLabel *label_10;
    QLabel *label_11;
    QLabel *label_12;
    QFrame *frame_3;
    QLabel *label;
    QLabel *lblCartTitle;
    QPushButton *pushButton;
    QWidget *widget;
    QFrame *frame;
    QPushButton *btnCheckout;
    QLabel *label_13;
    QLabel *label_7;
    QLabel *lblTotalPrice_2;
    QPushButton *btnGuide;
    QPushButton *btnHome;
    QLabel *label_4;
    QLabel *label_8;
    QLabel *label_2;
    QLabel *label_3;

    void setupUi(QWidget *PageCart)
    {
        if (PageCart->objectName().isEmpty())
            PageCart->setObjectName(QString::fromUtf8("PageCart"));
        PageCart->resize(800, 480);
        PageCart->setStyleSheet(QString::fromUtf8("background-color: rgb(242, 244, 245);\n"
""));
        horizontalLayout = new QHBoxLayout(PageCart);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        frame_2 = new QFrame(PageCart);
        frame_2->setObjectName(QString::fromUtf8("frame_2"));
        frame_2->setFrameShape(QFrame::Shape::StyledPanel);
        frame_2->setFrameShadow(QFrame::Shadow::Raised);
        widget_2 = new QWidget(frame_2);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        widget_2->setGeometry(QRect(10, 60, 531, 371));
        widget_2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border-radius: 16px;\n"
""));
        tableCart = new QTableWidget(widget_2);
        tableCart->setObjectName(QString::fromUtf8("tableCart"));
        tableCart->setGeometry(QRect(10, 120, 511, 241));
        label_10 = new QLabel(widget_2);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(50, 70, 71, 31));
        label_10->setStyleSheet(QString::fromUtf8("font: 14pt \"Ubuntu Mono\";"));
        label_11 = new QLabel(widget_2);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(230, 70, 71, 31));
        label_11->setStyleSheet(QString::fromUtf8("font: 14pt \"Ubuntu Mono\";"));
        label_12 = new QLabel(widget_2);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(415, 70, 71, 31));
        label_12->setStyleSheet(QString::fromUtf8("font: 14pt \"Ubuntu Mono\";"));
        frame_3 = new QFrame(widget_2);
        frame_3->setObjectName(QString::fromUtf8("frame_3"));
        frame_3->setGeometry(QRect(0, 0, 531, 61));
        frame_3->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"\n"
"border-style: solid;\n"
"border-top: 1px solid rgb(255, 255, 255);\n"
"border-left: 1px solid rgb(255, 255, 255);\n"
"border-right: 1px solid rgb(255, 255, 255);\n"
"border-bottom: 1px solid rgb(200, 200, 200);\n"
"\n"
"border-radius: 0px;\n"
""));
        frame_3->setFrameShape(QFrame::Shape::StyledPanel);
        frame_3->setFrameShadow(QFrame::Shadow::Raised);
        label = new QLabel(frame_3);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(10, 10, 81, 31));
        label->setStyleSheet(QString::fromUtf8("font: 700 23pt \"Umpush\";\n"
"\n"
"\n"
"border-style: solid;\n"
"border-top: 1px solid rgb(255, 255, 255);\n"
"border-left: 1px solid rgb(255, 255, 255);\n"
"border-right: 1px solid rgb(255, 255, 255);\n"
"border-bottom: 1px solid rgb(255, 255, 255);\n"
"\n"
"border-radius: 0px;\n"
""));
        lblCartTitle = new QLabel(frame_3);
        lblCartTitle->setObjectName(QString::fromUtf8("lblCartTitle"));
        lblCartTitle->setGeometry(QRect(90, 20, 151, 17));
        lblCartTitle->setStyleSheet(QString::fromUtf8("font: 13pt \"Umpush\";\n"
"\n"
"\n"
"border-style: solid;\n"
"border-top: 1px solid rgb(255, 255, 255);\n"
"border-left: 1px solid rgb(255, 255, 255);\n"
"border-right: 1px solid rgb(255, 255, 255);\n"
"border-bottom: 1px solid rgb(255, 255, 255);\n"
"\n"
"border-radius: 0px;\n"
""));
        pushButton = new QPushButton(frame_3);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(410, 10, 111, 41));
        pushButton->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: rgb(224, 27, 36);\n"
"    font: 300 12pt \"Umpush\";\n"
"    color: rgb(255, 255, 255);\n"
"    border: none;\n"
"    border-radius: 14px;\n"
"    padding: 10px 18px;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: rgb(192, 28, 40);\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: rgb(120, 0, 10);\n"
"}\n"
"QPushButton:disabled {\n"
"    background-color: rgb(120, 120, 120);\n"
"    color: rgb(230, 230, 230);\n"
"}\n"
""));
        widget = new QWidget(frame_2);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(550, 60, 191, 261));
        widget->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        frame = new QFrame(widget);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setGeometry(QRect(0, 180, 351, 81));
        frame->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"\n"
"border-style: solid;\n"
"border-top: 1px solid rgb(200, 200, 200);\n"
"border-left: 1px solid rgb(255, 255, 255);\n"
"border-right: 1px solid rgb(255, 255, 255);\n"
"border-bottom: 1px solid rgb(255, 255, 255);\n"
"\n"
"border-radius: 0px;\n"
""));
        frame->setFrameShape(QFrame::Shape::StyledPanel);
        frame->setFrameShadow(QFrame::Shadow::Raised);
        btnCheckout = new QPushButton(frame);
        btnCheckout->setObjectName(QString::fromUtf8("btnCheckout"));
        btnCheckout->setGeometry(QRect(3, 21, 181, 41));
        btnCheckout->setStyleSheet(QString::fromUtf8("background-color: rgb(53, 132, 228);\n"
"color: rgb(255, 255, 255);\n"
"border: none;\n"
"border-radius: 14px;\n"
"padding: 10px 18px;\n"
""));
        label_13 = new QLabel(widget);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setGeometry(QRect(0, 30, 321, 31));
        label_13->setStyleSheet(QString::fromUtf8("image: url(:/new/prefix1/Gemini_Generated_Image_u34sf6u34sf6u34s.png);"));
        label_7 = new QLabel(widget);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(10, 20, 111, 31));
        label_7->setStyleSheet(QString::fromUtf8("font: 700 18pt \"Umpush\";\n"
"background-color: rgb(255, 255, 255);\n"
"border: none;\n"
"border-radius: 16px;\n"
""));
        lblTotalPrice_2 = new QLabel(widget);
        lblTotalPrice_2->setObjectName(QString::fromUtf8("lblTotalPrice_2"));
        lblTotalPrice_2->setGeometry(QRect(20, 100, 161, 51));
        lblTotalPrice_2->setStyleSheet(QString::fromUtf8("font: 700 21pt \"Umpush\";\n"
"background-color: rgb(255, 255, 255);\n"
"border: none;\n"
"border-radius: 16px;\n"
""));
        btnGuide = new QPushButton(frame_2);
        btnGuide->setObjectName(QString::fromUtf8("btnGuide"));
        btnGuide->setGeometry(QRect(640, 10, 41, 41));
        btnGuide->setMinimumSize(QSize(30, 30));
        btnGuide->setStyleSheet(QString::fromUtf8("font: 23pt \"Ria Sans\";\n"
"image: url(:/etc/search.png);\n"
"border-radius: 0px;\n"
"background-color: rgb(242, 244, 245);\n"
""));
        btnGuide->setIconSize(QSize(28, 80));
        btnHome = new QPushButton(frame_2);
        btnHome->setObjectName(QString::fromUtf8("btnHome"));
        btnHome->setGeometry(QRect(700, 10, 41, 41));
        btnHome->setMinimumSize(QSize(30, 30));
        btnHome->setStyleSheet(QString::fromUtf8("font: 23pt \"Ria Sans\";\n"
"image: url(:/etc/home.png);\n"
"border-radius: 0px;\n"
"padding: 0px 0px;\n"
"background-color: rgb(242, 244, 245);\n"
""));
        btnHome->setIconSize(QSize(28, 80));
        label_4 = new QLabel(frame_2);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(330, 20, 121, 20));
        label_4->setStyleSheet(QString::fromUtf8("font: 13pt \"Ubuntu Condensed\";\n"
"color: rgb(0, 0, 0);\n"
"\n"
"color: rgb(154, 153, 150);"));
        label_8 = new QLabel(frame_2);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(470, 19, 111, 17));
        label_8->setStyleSheet(QString::fromUtf8("font: 13pt \"Ubuntu Condensed\";\n"
"color: rgb(154, 153, 150);\n"
"background-color: #F2F4F7;"));
        label_2 = new QLabel(frame_2);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(220, 19, 111, 17));
        label_2->setStyleSheet(QString::fromUtf8("font: 13pt \"Ubuntu Condensed\";\n"
"background-color: #F2F4F7;\n"
"background-color: #F2F4F7;"));
        label_3 = new QLabel(frame_2);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(550, 330, 191, 101));
        label_3->setStyleSheet(QString::fromUtf8("image: url(:/etc/counter.png);\n"
"border-radius: 16px;\n"
""));

        horizontalLayout->addWidget(frame_2);


        retranslateUi(PageCart);

        QMetaObject::connectSlotsByName(PageCart);
    } // setupUi

    void retranslateUi(QWidget *PageCart)
    {
        PageCart->setWindowTitle(QCoreApplication::translate("PageCart", "Form", nullptr));
        label_10->setText(QCoreApplication::translate("PageCart", "Product", nullptr));
        label_11->setText(QCoreApplication::translate("PageCart", "Count", nullptr));
        label_12->setText(QCoreApplication::translate("PageCart", "Price", nullptr));
        label->setText(QCoreApplication::translate("PageCart", "Cart", nullptr));
        lblCartTitle->setText(QString());
        pushButton->setText(QCoreApplication::translate("PageCart", "clear cart", nullptr));
        btnCheckout->setText(QCoreApplication::translate("PageCart", "\352\262\260\354\240\234\355\225\230\352\270\260", nullptr));
        label_13->setText(QString());
        label_7->setText(QCoreApplication::translate("PageCart", "\354\264\235 \352\270\210\354\225\241", nullptr));
        lblTotalPrice_2->setText(QString());
        btnGuide->setText(QString());
        btnHome->setText(QString());
        label_4->setText(QCoreApplication::translate("PageCart", "O Checkout   ", nullptr));
        label_8->setText(QCoreApplication::translate("PageCart", "O Payment    ", nullptr));
        label_2->setText(QCoreApplication::translate("PageCart", "O Cart    ", nullptr));
        label_3->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class PageCart: public Ui_PageCart {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PAGECART_H
