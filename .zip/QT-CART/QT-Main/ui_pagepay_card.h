/********************************************************************************
** Form generated from reading UI file 'pagepay_card.ui'
**
** Created by: Qt User Interface Compiler version 5.15.15
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PAGEPAY_CARD_H
#define UI_PAGEPAY_CARD_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_pagepay_card
{
public:

    void setupUi(QWidget *pagepay_card)
    {
        if (pagepay_card->objectName().isEmpty())
            pagepay_card->setObjectName(QString::fromUtf8("pagepay_card"));
        pagepay_card->resize(800, 480);
        pagepay_card->setStyleSheet(QString::fromUtf8("background-color: rgb(36, 31, 49);"));

        retranslateUi(pagepay_card);

        QMetaObject::connectSlotsByName(pagepay_card);
    } // setupUi

    void retranslateUi(QWidget *pagepay_card)
    {
        pagepay_card->setWindowTitle(QCoreApplication::translate("pagepay_card", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class pagepay_card: public Ui_pagepay_card {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PAGEPAY_CARD_H
