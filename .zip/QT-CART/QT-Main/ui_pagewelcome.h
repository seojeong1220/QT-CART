/********************************************************************************
** Form generated from reading UI file 'pagewelcome.ui'
**
** Created by: Qt User Interface Compiler version 5.15.15
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PAGEWELCOME_H
#define UI_PAGEWELCOME_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_PageWelcome
{
public:
    QHBoxLayout *horizontalLayout;
    QFrame *frame;
    QLabel *start_text;
    QWidget *start_image;
    QLabel *cart_image;
    QLabel *wind_image;
    QLabel *qtcart_text;
    QPushButton *start_button;

    void setupUi(QWidget *PageWelcome)
    {
        if (PageWelcome->objectName().isEmpty())
            PageWelcome->setObjectName(QString::fromUtf8("PageWelcome"));
        PageWelcome->resize(800, 480);
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(11);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(PageWelcome->sizePolicy().hasHeightForWidth());
        PageWelcome->setSizePolicy(sizePolicy);
        QFont font;
        font.setBold(false);
        PageWelcome->setFont(font);
        PageWelcome->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        horizontalLayout = new QHBoxLayout(PageWelcome);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        frame = new QFrame(PageWelcome);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setFrameShape(QFrame::Shape::StyledPanel);
        frame->setFrameShadow(QFrame::Shadow::Raised);
        start_text = new QLabel(frame);
        start_text->setObjectName(QString::fromUtf8("start_text"));
        start_text->setGeometry(QRect(0, 340, 781, 22));
        start_text->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
""));
        start_text->setAlignment(Qt::AlignmentFlag::AlignCenter);
        start_image = new QWidget(frame);
        start_image->setObjectName(QString::fromUtf8("start_image"));
        start_image->setGeometry(QRect(300, 80, 211, 171));
        start_image->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        cart_image = new QLabel(start_image);
        cart_image->setObjectName(QString::fromUtf8("cart_image"));
        cart_image->setGeometry(QRect(90, 30, 121, 101));
        cart_image->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        wind_image = new QLabel(start_image);
        wind_image->setObjectName(QString::fromUtf8("wind_image"));
        wind_image->setGeometry(QRect(0, 70, 61, 71));
        wind_image->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        qtcart_text = new QLabel(frame);
        qtcart_text->setObjectName(QString::fromUtf8("qtcart_text"));
        qtcart_text->setGeometry(QRect(5, 250, 771, 77));
        qtcart_text->setLayoutDirection(Qt::LayoutDirection::LeftToRight);
        qtcart_text->setStyleSheet(QString::fromUtf8("font: 700 40pt \"Ria Sans\";\n"
"color: rgb(87, 227, 137);\n"
"background-color: rgb(255, 255, 255);\n"
""));
        qtcart_text->setAlignment(Qt::AlignmentFlag::AlignCenter);
        start_button = new QPushButton(frame);
        start_button->setObjectName(QString::fromUtf8("start_button"));
        start_button->setGeometry(QRect(260, 390, 261, 30));
        start_button->setStyleSheet(QString::fromUtf8("font: 700 11pt \"Ria Sans\";\n"
"QPushButton {\n"
"    background-color: rgb(224, 27, 36);  /* \342\234\205 \352\270\260\353\263\270 \354\203\201\355\203\234: \353\215\224 \354\247\204\355\225\234 \353\271\250\352\260\225 */\n"
"	\n"
"	font: 300 14pt \"Umpush\";\n"
"    color: rgb(255, 255, 255);\n"
"    border: none;\n"
"    border-radius: 14px;                /* \342\234\205 \353\217\231\352\270\200\353\217\231\352\270\200 */\n"
"    padding: 10px 18px;                 /* \353\262\204\355\212\274 \355\201\254\352\270\260/\354\227\254\353\260\261 */\n"
"}\n"
"\n"
"\n"
""));

        horizontalLayout->addWidget(frame);


        retranslateUi(PageWelcome);

        QMetaObject::connectSlotsByName(PageWelcome);
    } // setupUi

    void retranslateUi(QWidget *PageWelcome)
    {
        PageWelcome->setWindowTitle(QCoreApplication::translate("PageWelcome", "Form", nullptr));
        start_text->setText(QCoreApplication::translate("PageWelcome", "\354\213\234\354\236\221\355\225\230\352\270\260 \353\262\204\355\212\274\354\235\204 \353\210\214\353\237\254 \354\207\274\355\225\221\354\235\204 \354\213\234\354\236\221\355\225\230\354\204\270\354\232\224", nullptr));
        cart_image->setText(QString());
        wind_image->setText(QString());
        qtcart_text->setText(QCoreApplication::translate("PageWelcome", "QT CART", nullptr));
        start_button->setText(QCoreApplication::translate("PageWelcome", "\354\213\234\354\236\221\355\225\230\352\270\260", nullptr));
    } // retranslateUi

};

namespace Ui {
    class PageWelcome: public Ui_PageWelcome {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PAGEWELCOME_H
