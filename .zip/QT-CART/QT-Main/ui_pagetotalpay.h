/********************************************************************************
** Form generated from reading UI file 'pagetotalpay.ui'
**
** Created by: Qt User Interface Compiler version 5.15.15
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PAGETOTALPAY_H
#define UI_PAGETOTALPAY_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_PageTotalPay
{
public:
    QHBoxLayout *horizontalLayout;
    QFrame *frame;
    QLabel *lblTitle;
    QLabel *lblSubTitle;
    QLabel *lblIcon;

    void setupUi(QWidget *PageTotalPay)
    {
        if (PageTotalPay->objectName().isEmpty())
            PageTotalPay->setObjectName(QString::fromUtf8("PageTotalPay"));
        PageTotalPay->resize(800, 480);
        PageTotalPay->setStyleSheet(QString::fromUtf8("background-color: rgb(51, 209, 122);"));
        horizontalLayout = new QHBoxLayout(PageTotalPay);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        frame = new QFrame(PageTotalPay);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setFrameShape(QFrame::Shape::StyledPanel);
        frame->setFrameShadow(QFrame::Shadow::Raised);
        lblTitle = new QLabel(frame);
        lblTitle->setObjectName(QString::fromUtf8("lblTitle"));
        lblTitle->setGeometry(QRect(260, 200, 67, 17));
        lblSubTitle = new QLabel(frame);
        lblSubTitle->setObjectName(QString::fromUtf8("lblSubTitle"));
        lblSubTitle->setGeometry(QRect(270, 230, 67, 17));
        lblIcon = new QLabel(frame);
        lblIcon->setObjectName(QString::fromUtf8("lblIcon"));
        lblIcon->setGeometry(QRect(250, 140, 111, 17));

        horizontalLayout->addWidget(frame);


        retranslateUi(PageTotalPay);

        QMetaObject::connectSlotsByName(PageTotalPay);
    } // setupUi

    void retranslateUi(QWidget *PageTotalPay)
    {
        PageTotalPay->setWindowTitle(QCoreApplication::translate("PageTotalPay", "Form", nullptr));
        lblTitle->setText(QString());
        lblSubTitle->setText(QString());
        lblIcon->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class PageTotalPay: public Ui_PageTotalPay {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PAGETOTALPAY_H
